<!-- SIDEBAR -->
<div class="sidebar">
	<?php if ( is_active_sidebar( 'widget_sidebar_forum' ) ) : ?>
		<?php dynamic_sidebar( 'widget_sidebar_forum' ); ?>
	<?php endif; ?>
</div><!-- END SIDEBAR --><div class="spacer"></div>