<div class="share">
	<span class="pull-left"><?php echo __( 'Share this Post :', 'mtcframework' ); ?></span>
	<?php mtc_social_share(); ?>
</div>